class DataManager:
    #This class is responsible for talking to the Google Sheet.
    pass